# AdSellix AI Audit Tool - Phase 1 MVP

**Version:** 1.0.0  
**Status:** Phase 1 Complete  
**Date:** February 2026

---

## 📁 Project Structure

```
adsellix_audit_v1/
├── app.py                    # Main Streamlit application
├── requirements.txt          # Python dependencies
├── core/                     # PROTECTED - Core modules
│   ├── __init__.py
│   ├── data_loaders.py       # File parsing for all report types
│   ├── hierarchy.py          # Parent-child ASIN hierarchy
│   └── calculations.py       # Metrics, scoring, formulas
├── ppc/                      # PROTECTED - PPC analysis
│   ├── __init__.py
│   └── analysis.py           # Campaign, keyword, search term analysis
├── modules/                  # Feature modules
│   ├── __init__.py
│   └── keep_kill.py          # Keep/Kill Matrix scoring
├── utils/                    # Utility functions
│   └── __init__.py
└── backups/                  # Version backups
```

---

## 🚀 Deployment Instructions

### Option 1: Streamlit Cloud (Recommended)

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Phase 1 MVP"
   git remote add origin https://github.com/YOUR_USERNAME/adsellix-audit.git
   git push -u origin main
   ```

2. **Deploy on Streamlit Cloud:**
   - Go to [share.streamlit.io](https://share.streamlit.io)
   - Click "New app"
   - Select your repository
   - Main file path: `app.py`
   - Click "Deploy"

### Option 2: Local Development

1. **Create virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # or
   venv\Scripts\activate     # Windows
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the app:**
   ```bash
   streamlit run app.py
   ```

---

## 📊 Supported Reports

| Report | Format | Status |
|--------|--------|--------|
| SQP Brand View | CSV | ✅ Ready |
| SQP ASIN View | CSV | ✅ Ready |
| Business Report | CSV | ✅ Ready |
| PPC Bulk Sheet | XLSX | ✅ Ready |
| Inventory Report | CSV | ✅ Ready |
| COGS | CSV | ✅ Ready |
| FBA/Referral Fees | CSV | ✅ Ready |
| Category Listing Report | XLSM | ✅ Ready |
| Top Search Terms | CSV | 🔜 Phase 2 |
| Returns Report | TSV | 🔜 Phase 2 |

---

## 🔐 Code Protection Protocol

### Protected Modules (Do Not Modify)
- `core/data_loaders.py`
- `core/hierarchy.py`
- `core/calculations.py`
- `ppc/analysis.py`

### Before Making Changes:
1. Create a backup: `cp -r adsellix_audit_v1 backups/v1.0.0_YYYYMMDD`
2. Document the change
3. Test thoroughly before deploying

### Backup Naming Convention:
`v{VERSION}_{DATE}_{DESCRIPTION}`
Example: `v1.0.1_20260205_fixed_sqp_parsing`

---

## 🎯 MVP Features (Phase 1)

### ✅ Included
- [x] Marketplace selection (US, UK, EU, etc.)
- [x] Multi-report data upload
- [x] SQP Brand View analysis with period comparison
- [x] Full PPC analysis (SP, SB, SD)
- [x] Search term recommendations
- [x] Waste detection
- [x] Inventory health dashboard
- [x] Keep/Kill Matrix with scoring
- [x] Brand Health Score
- [x] Auto Hero ASIN detection

### 🔜 Phase 2
- [ ] Top Search Terms market intelligence
- [ ] Market Basket analysis
- [ ] Returns analysis
- [ ] AI-generated executive summary
- [ ] PDF export
- [ ] Google Sheets export

---

## 📞 Support

For questions or issues, contact the AdSellix team.

---

## 📜 Changelog

### v1.0.0 (2026-02-05)
- Initial Phase 1 MVP release
- Core data loaders for all report types
- PPC analysis with waste detection
- Keep/Kill Matrix scoring
- Brand Health Score calculation
